Update 
- Fix text split for DM Series
- OCR camera Integration